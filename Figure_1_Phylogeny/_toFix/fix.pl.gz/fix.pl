#!usr/bin/perl
use 5.010;

while(<>) {
	@line = split("\t",$_);
	if(@line[5] == 1) {
		@line2 = split('_',@line[4]);
		if(@line2[1] eq "sp") {
			say(@line[4]);
		}
	}
}
